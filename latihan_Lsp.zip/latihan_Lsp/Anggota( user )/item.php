<?php 
    class Item{
        var $id_buku;
        // var integer
        var $judul_buku;
        // var string
        var $harga;
        // var integer
        var $qty;
        // var quantity
    }
?>