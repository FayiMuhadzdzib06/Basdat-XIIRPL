<?php 
    // konfigurasi database
    $host = "localhost";
    $user = "root";
    $password = "";
    $db = "basdat_praktek";

    // perintah untuk mengkoneksikan database
    $koneksi = mysqli_connect($host, $user, $password, $db);
?>